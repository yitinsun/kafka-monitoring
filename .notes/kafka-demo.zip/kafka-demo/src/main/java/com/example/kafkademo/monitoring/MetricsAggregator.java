package com.example.kafkademo.monitoring;

import com.example.kafkademo.model.Events.MetricSample;
import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;
import java.time.Duration;
import java.time.Instant;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import org.springframework.stereotype.Component;

/** Turns the metric stream into Prometheus-scrapable gauges plus an end-to-end pipeline latency timer. */
@Component
public class MetricsAggregator {

    private final MeterRegistry registry;
    private final ConcurrentMap<String, Stats> stats = new ConcurrentHashMap<>();

    public MetricsAggregator(MeterRegistry registry) {
        this.registry = registry;
    }

    public void record(MetricSample s) {
        Stats st = stats.computeIfAbsent(s.service() + "|" + s.metric(), k -> {
            Stats n = new Stats();
            Gauge.builder("app.service.metric.ewma", n, Stats::ewma)
                    .tags("service", s.service(), "metric", s.metric()).register(registry);
            Gauge.builder("app.service.metric.max", n, Stats::max)
                    .tags("service", s.service(), "metric", s.metric()).register(registry);
            return n;
        });
        st.add(s.value());

        // time from "sample taken" to "sample consumed": the real health signal of the Kafka pipeline
        registry.timer("app.kafka.e2e.latency", "topic", "system-metrics")
                .record(Duration.between(s.ts(), Instant.now()));
    }

    static final class Stats {
        private double ewma = Double.NaN;
        private double max;

        synchronized void add(double v) {
            ewma = Double.isNaN(ewma) ? v : 0.2 * v + 0.8 * ewma;
            max = Math.max(max, v);
        }

        synchronized double ewma() { return Double.isNaN(ewma) ? 0 : ewma; }

        synchronized double max() { return max; }
    }
}
