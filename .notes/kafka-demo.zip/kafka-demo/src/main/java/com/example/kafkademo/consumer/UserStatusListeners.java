package com.example.kafkademo.consumer;

import com.example.kafkademo.config.AppKafkaProperties;
import com.example.kafkademo.model.Events.UserStatusEvent;
import com.example.kafkademo.service.UserStatusStore;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

@Component
public class UserStatusListeners {

    private static final Logger log = LoggerFactory.getLogger(UserStatusListeners.class);

    private final UserStatusStore store;
    private final KafkaTemplate<String, Object> kafka;
    private final AppKafkaProperties props;

    public UserStatusListeners(UserStatusStore store, KafkaTemplate<String, Object> kafka, AppKafkaProperties props) {
        this.store = store;
        this.kafka = kafka;
        this.props = props;
    }

    /**
     * Group "user-status-processor": 12 partitions, 6 threads -> each thread owns 2 partitions.
     * Run a 2nd app instance and Kafka rebalances to 12 consumers in total (1 partition each).
     */
    @KafkaListener(
            id = "user-status-processor",
            topics = "${app.kafka.topics.user-status.name}",
            groupId = "${app.kafka.groups.user-status-processor.group-id}",
            concurrency = "${app.kafka.groups.user-status-processor.concurrency}",
            containerFactory = "recordFactory")
    public void process(ConsumerRecord<String, UserStatusEvent> record) {
        UserStatusEvent e = record.value();
        if (e.status() == null || e.userId() == null || e.userId().isBlank()) {
            throw new IllegalArgumentException("Invalid status event at offset " + record.offset()); // -> DLT, no retry
        }
        if (store.apply(e)) {
            // publish latest state to the compacted changelog topic (same key -> same partition)
            kafka.send(props.topic("user-status-changelog"), e.userId(), e);
            log.info("[processor p{}] {} -> {}", record.partition(), e.userId(), e.status());
        } else {
            log.debug("Ignored stale event for {}", e.userId());
        }
    }

    /** Independent group => receives every event again. Lighter work, so only 3 threads (4 partitions each). */
    @KafkaListener(
            id = "user-status-audit",
            topics = "${app.kafka.topics.user-status.name}",
            groupId = "${app.kafka.groups.user-status-audit.group-id}",
            concurrency = "${app.kafka.groups.user-status-audit.concurrency}",
            containerFactory = "recordFactory")
    public void audit(ConsumerRecord<String, UserStatusEvent> record) {
        UserStatusEvent e = record.value();
        log.debug("[audit p{} o{}] user={} status={} reason={}",
                record.partition(), record.offset(), e.userId(), e.status(), e.reason());
    }
}
