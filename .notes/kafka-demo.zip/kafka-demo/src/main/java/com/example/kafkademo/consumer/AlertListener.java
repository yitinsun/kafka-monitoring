package com.example.kafkademo.consumer;

import com.example.kafkademo.model.Events.Alert;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class AlertListener {

    private static final Logger log = LoggerFactory.getLogger(AlertListener.class);

    /** 3 partitions -> 3 threads is the useful maximum; thread owning partition 0 handles only CRITICAL alerts. */
    @KafkaListener(
            id = "alert-notifier",
            topics = "${app.kafka.topics.alerts.name}",
            groupId = "${app.kafka.groups.alert-notifier.group-id}",
            concurrency = "${app.kafka.groups.alert-notifier.concurrency}",
            containerFactory = "recordFactory")
    public void notify(ConsumerRecord<String, Alert> record) {
        Alert a = record.value();
        if (record.partition() == 0) {
            log.warn("PAGE ON-CALL: {} {} = {} (limit {})", a.service(), a.metric(), a.value(), a.threshold());
        } else {
            log.info("Ticket: {} {} = {} (limit {})", a.service(), a.metric(), a.value(), a.threshold());
        }
    }
}
