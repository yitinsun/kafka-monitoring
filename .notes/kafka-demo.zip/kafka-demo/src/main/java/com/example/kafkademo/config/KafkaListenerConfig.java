package com.example.kafkademo.config;

import org.apache.kafka.common.TopicPartition;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.listener.DeadLetterPublishingRecoverer;
import org.springframework.kafka.listener.DefaultErrorHandler;
import org.springframework.kafka.support.ExponentialBackOffWithMaxRetries;

/**
 * Note: concurrency is NOT set here. Each @KafkaListener sets its own from app.kafka.groups.*,
 * which overrides the factory default. Kafka producer/consumer client metrics are bound to
 * Micrometer automatically by Spring Boot's actuator (kafka.consumer.*, kafka.producer.*).
 */
@Configuration
public class KafkaListenerConfig {

    @Bean
    DefaultErrorHandler kafkaErrorHandler(KafkaTemplate<String, Object> template) {
        // partition -1 => let the producer pick, so the DLT can have fewer partitions than the source topic
        var recoverer = new DeadLetterPublishingRecoverer(template,
                (record, ex) -> new TopicPartition(record.topic() + ".DLT", -1));

        var backOff = new ExponentialBackOffWithMaxRetries(3);
        backOff.setInitialInterval(500);
        backOff.setMultiplier(2.0);

        var handler = new DefaultErrorHandler(recoverer, backOff);
        handler.addNotRetryableExceptions(IllegalArgumentException.class); // bad data: straight to DLT
        return handler;
    }

    /** One record at a time, commit after each record: for user-status work. */
    @Bean
    ConcurrentKafkaListenerContainerFactory<String, Object> recordFactory(
            ConsumerFactory<String, Object> cf, DefaultErrorHandler errorHandler) {
        var f = new ConcurrentKafkaListenerContainerFactory<String, Object>();
        f.setConsumerFactory(cf);
        f.setCommonErrorHandler(errorHandler);
        f.getContainerProperties().setAckMode(ContainerProperties.AckMode.RECORD);
        f.getContainerProperties().setObservationEnabled(true);
        return f;
    }

    /** Whole poll() as a batch, commit after the batch: for high-volume metrics. */
    @Bean
    ConcurrentKafkaListenerContainerFactory<String, Object> batchFactory(
            ConsumerFactory<String, Object> cf, DefaultErrorHandler errorHandler) {
        var f = new ConcurrentKafkaListenerContainerFactory<String, Object>();
        f.setConsumerFactory(cf);
        f.setBatchListener(true);
        f.setCommonErrorHandler(errorHandler);
        f.getContainerProperties().setAckMode(ContainerProperties.AckMode.BATCH);
        f.getContainerProperties().setObservationEnabled(true);
        return f;
    }
}
